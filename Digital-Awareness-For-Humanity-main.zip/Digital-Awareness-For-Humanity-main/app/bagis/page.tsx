"use client";
import React from 'react';
import Navbar from '@/components/Navbar';

export default function Bagis() {
  return (
    <main className="relative min-h-screen w-full bg-[#020617] overflow-hidden">
      <Navbar />
      
      {/* --- TAM EKRAN VİDEO KATMANI (Sadece PC'de Gözükür) --- */}
      <div className="absolute inset-0 z-0 w-full h-full hidden md:block">
        <div className="relative w-full h-full">
          <iframe
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
            style={{
              width: '100vw',
              height: '56.25vw', /* 16:9 Oranı */
              minHeight: '100vh',
              minWidth: '177.77vh',
            }}
            src="https://www.youtube.com/embed/zcruIov45bI?autoplay=1&mute=1&loop=1&playlist=zcruIov45bI&controls=0&showinfo=0&rel=0&modestbranding=1&iv_load_policy=3"
            allow="autoplay; encrypted-media"
          />
          
          {/* VİDEO ÜZERİ KARARTMA */}
          <div className="absolute inset-0 bg-black/50 backdrop-blur-[1px]" />
          {/* Alttan ve üstten yumuşak geçiş */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-black/80" />
        </div>
      </div>

      {/* --- MOBİL İÇİN DEKORATİF ARKA PLAN (Sadece Mobilde Gözükür) --- */}
      <div className="absolute inset-0 z-0 md:hidden overflow-hidden">
        {/* Lavcivert derinlik için hafif bir ışık süzmesi */}
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-emerald-900/10 blur-[100px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-900/10 blur-[100px]" />
      </div>

      {/* --- İÇERİK KATMANI --- */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-6 text-center">
        <div className="max-w-5xl space-y-8 md:space-y-10">
          
          <h1 className="text-3xl md:text-7xl font-black tracking-tighter text-white uppercase leading-[1.1] md:leading-none drop-shadow-[0_10px_30px_rgba(0,0,0,0.8)]">
            Bugün insanlık adına <br className="hidden md:block" />
            <span className="text-emerald-500 drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]"> bir iyilik yapın!</span>
          </h1>

          <div className="flex flex-col items-center gap-4 md:gap-6">
            <div className="w-20 md:w-32 h-[2px] bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.8)]" />
            
            <p className="text-lg md:text-3xl font-light italic text-slate-100 drop-shadow-[0_4px_10px_rgba(0,0,0,1)] max-w-3xl px-4 md:px-0">
              "Kendi çevrenizden başlamaya ne dersiniz? :)" <br className="md:hidden" />
              <span className="text-sm md:text-2xl not-italic opacity-80 block mt-2 md:inline"> - founder of DAFH, R.A.A.</span>
            </p>
          </div>

          <p className="text-emerald-400/90 text-[10px] md:text-[14px] tracking-[0.4em] md:tracking-[0.8em] uppercase font-bold drop-shadow-[0_2px_5px_rgba(0,0,0,0.5)] pt-4">
            Digital Awareness for Humanity Community
          </p>
        </div>
      </div>

      {/* Dekoratif Yanıp Sönen Işık */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce">
        <div className="w-[1px] h-12 bg-gradient-to-b from-emerald-500 to-transparent" />
      </div>
    </main>
  );
}