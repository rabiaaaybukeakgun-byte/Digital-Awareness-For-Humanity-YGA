"use client";
import { useState } from 'react';
import Navbar from '@/components/Navbar';

interface NewsItem {
  id: number;
  date: string;
  title: string;
  excerpt: string;
  category: string;
  tag: string;
  url: string;
}

export default function Haberler() {
  const [news] = useState<NewsItem[]>([
    {
      id: 1,
      date: "17 Ocak 2026",
      category: "KÜRESEL",
      tag: "KRİTİK",
      title: "BM’nin “High Seas Treaty” okyanus koruma anlaşması yürürlüğe girdi",
      excerpt: "Birleşmiş Milletler tarafından desteklenen, Biyoçeşitlilik Ulusal Yetki Dışı Alanlarda Koruma Anlaşması (BBNJ), 17 Ocak 2026 itibarıyla yürürlüğe girdi ve uluslararası sularda deniz yaşamını korumaya yönelik bağlayıcı hükümler içeriyor.",
      url: "https://www.un.org/en/desa/game-changing-international-marine-protection-treaty"
    },
    {
      id: 2,
      date: "26 Mart 2025",
      category: "CANLILAR",
      tag: "KRİTİK",
      title: "İmparator Penguenleri Tehlike Altında — Gelecekte Kaybolabilirler",
      excerpt: "Bir bilimsel çağrıya göre imparator penguenler iklim değişikliği nedeniyle 2100’e kadar yok olabilir; bu yüzden bilim insanları bu türün tehdit seviyesinin IUCN tarafından Vulnerable (Hassas) veya Endangered (Tehlikede) olarak güncellenmesini istiyorlar. Bu, iklim krizi ve deniz buzu kaybının doğrudan türlerin kurtarma şansını etkilediğini gösteren önemli bir bilimsel uyarı niteliğinde.",
      url: "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwiG25zCicGSAxWanf0HHdTfLkwQFnoECBkQAQ&url=https%3A%2F%2Foceanographicmagazine.com%2Fnews%2Femperor-penguins-could-be-lost-to-climate-change-by-2100%2F&usg=AOvVaw2JZEAQ67x63v1fZx_2h4fk&opi=89978449"
    },
    {
      id: 3,
      date: "12 Ekim 2025",
      category: "TEKNOLOJİ",
      tag: "YENİ",
      title: "Arı, Kelebek ve Diğer Polinatör Türlerde Büyük Artış",
      excerpt: "Avrupa’da yaban arıları ve kelebekler hızla tehdit altına giriyor. Uluslararası değerlendirmelere göre Avrupa’da yapılan IUCN değerlendirmesi, yaban arılarının ve kelebek türlerinin sayısında keskin bir artışla tehdit altındaki tür sayısını ortaya koydu. Örneğin: 1.928 yaban arısı türünden en az 172’si tehdit altında. Kelebek türleri de önemli bir artış gösterdi. Bu türler ekosistem işlevleri için kritik — polinasyon, gıda üretimi ve doğa döngüleri için hayati önemde.",
      url: "https://www.lemonde.fr/en/environment/article/2025/10/12/wild-butterflies-and-bees-face-growing-threats-across-europe_6746344_114.html"
    }
  ]);

  return (
    <div className="min-h-screen bg-[#020617] text-slate-300 font-sans selection:bg-emerald-500/30">
      <Navbar />

      <main className="relative z-[10] max-w-4xl mx-auto p-5 md:p-6 pt-28 md:pt-40 pb-20 pointer-events-auto">
        <header className="mb-10 md:mb-16 border-b border-white/10 pb-6 md:pb-8">
          <h1 className="text-3xl md:text-5xl font-light text-white tracking-tighter mb-4 leading-tight">
            Güncel <span className="text-emerald-400 font-medium">Gelişmeler</span>
          </h1>
          <p className="text-slate-500 tracking-[0.2em] md:tracking-[0.5em] text-[9px] md:text-[10px] uppercase">
            Dünyadan ve Dijitalden Son Durum Raporları
          </p>
        </header>

        <section className="flex flex-col gap-6 md:gap-8">
          {news.map((item) => (
            <article 
              key={item.id} 
              className="group relative bg-white/[0.02] border border-white/5 p-6 md:p-8 rounded-[1.5rem] md:rounded-[2rem] backdrop-blur-md transition-all duration-500 hover:bg-white/[0.04] hover:border-emerald-500/30"
            >
              {/* Üst Bilgi Satırı - Mobilde esnek yapı */}
              <div className="flex flex-row items-center justify-between gap-3 mb-4 md:mb-6">
                <div className="flex items-center gap-3 text-[9px] md:text-[10px] tracking-widest font-bold">
                  <span className="text-emerald-400 uppercase bg-emerald-500/10 px-2.5 py-1 rounded-full">{item.category}</span>
                  <span className="text-slate-500 whitespace-nowrap">{item.date}</span>
                </div>
                <span className="px-2 py-1 bg-white/5 rounded border border-white/10 text-[9px] md:text-[10px] text-slate-400 group-hover:text-emerald-400 transition-colors tracking-widest uppercase">
                  {item.tag}
                </span>
              </div>

              <h2 className="text-xl md:text-3xl font-light text-white mb-3 md:mb-4 leading-snug italic">
                {item.title}
              </h2>

              <p className="text-slate-400 leading-relaxed text-sm md:text-base font-light mb-6 line-clamp-3">
                {item.excerpt}
              </p>

              {/* Haber Kaynağı Linki - Mobilde daha belirgin tıklama alanı */}
              <a 
                href={item.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-[10px] md:text-xs tracking-[0.2em] uppercase text-emerald-500 font-semibold group-hover:gap-4 transition-all py-2"
              >
                HABER KAYNAĞINA GİT <span className="text-lg leading-none">→</span>
              </a>
            </article>
          ))}
        </section>
      </main>
    </div>
  );
}