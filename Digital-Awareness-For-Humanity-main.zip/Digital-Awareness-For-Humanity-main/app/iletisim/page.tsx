"use client";
import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import { Loader2 } from 'lucide-react';

export default function Iletisim() {
  useEffect(() => {
    const formLink = "https://docs.google.com/forms/d/e/1FAIpQLSdjLCksPflbuHiZOLK-uUSOljbXuDBoQpss_h64mtWqY38_NA/viewform?usp=publish-editor";
    
    // Küçük bir gecikme ekleyerek kullanıcının yönlendirme mesajını görmesini sağlıyoruz
    const timer = setTimeout(() => {
      window.location.href = formLink;
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <main className="min-h-screen bg-[#020617] text-white flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <Navbar />
      
      {/* Arka Plan Efekti */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-emerald-500/10 blur-[100px] rounded-full" />
      </div>

      <div className="text-center z-10 space-y-6">
        <div className="flex justify-center">
          <div className="relative">
            <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
            <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full animate-pulse" />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-xl md:text-2xl font-light tracking-[0.2em] text-white uppercase">
            Yönlendiriliyorsunuz
          </h1>
          <div className="flex items-center justify-center gap-1">
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce"></span>
          </div>
        </div>

        <p className="text-slate-500 text-[10px] md:text-xs tracking-widest uppercase max-w-[250px] mx-auto leading-relaxed">
          Görüş ve Öneriler Formu Güvenli Bir Şekilde Açılıyor
        </p>
      </div>

      {/* Alt Bilgi */}
      <div className="absolute bottom-10 left-0 right-0 text-center">
        <p className="text-[8px] text-slate-700 tracking-[0.5em] uppercase">
          External Redirect System v2.0
        </p>
      </div>
    </main>
  );
}