"use client";
import Navbar from '@/components/Navbar';
import { BookOpen, ExternalLink, Database } from 'lucide-react';

export default function Kaynaklar() {
  const sources = [
    { title: "Yıllık Köpek Balığı Katliamları", link: "https://www-sharkguardian-org.translate.goog/how-many-sharks-killed-each-year?_x_tr_sl=en&_x_tr_tl=tr&_x_tr_hl=tr&_x_tr_pto=rq&_x_tr_hist=true", desc: "Yıllık olarak insanlar tarafından katledilen veya avlanan köpekbalıklarının istatistiğini inceleyen kapsamlı veri seti." },
    { title: "Global Carbon Budget", link: "https://globalcarbonbudget.org", desc: "Yıllık CO2 salınım verileri, emisyon trendleri ve atmosferik karbon konsantrasyonu istatistikleri." },
    { title: "Hava Kirliliğine Bağlı Erken Ölümler", link: "https://temizhavahakki.org/kararapor2020/#:~:text=Türkiye%27de%20hava%20kirliliği%20Dünya,katından%20fazla%20ölüme%20sebep%20oluyor.", desc: "Hava kirlililği ve yetersiz arıtımdan kaynaklanan erken ölümlerin istatistik verileri." },
    { title: "İklime Bağlı Yaşanan İç Göçler", link: "https://yesilbuyume.org/i̇klim-gocu/", desc: "İklim değişiklikleri ve dünyaya verilen zarar sonucu yaşama uygun olmayan koşullara karşın yaşanan iklim göçlerini kapsar." },
    { title: "Tehdit Altındaki Türler", link: "https://tr.wikipedia.org/wiki/Neredeyse_tehdit_altındaki_türler", desc: "Yok olan habitatların veya aşırı avlanmanın karşısında yok olmaya yüz tutan/nesli tükenmek üzere olan canlı çeşitlerini içerir." },
    { title: "Plastik Atık Üretimi (Ton)", link: "https://ourworldindata.org/plastic-pollution", desc: "Dünyada her yıl üretilen plastik atıklerin ve bu atıkların çevreye zararını inceler." },
    { title: "AI Su Tüketimi (Litre)", link: "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwjFgIOF_MCSAxWiFBAIHdbZCKMQFnoECBgQAQ&url=https%3A%2F%2Fwww.bbc.com%2Fturkce%2Farticles%2Fcp3kl6eql3lo&usg=AOvVaw3A2sADBCYpDvI3KLikEg7C&opi=89978449", desc: "Yapay zeka araçlarının çeşitli görevleri yerine getirirken sistemleri soğutmak için kullanılan su miktarının istatistikleri" },
    { title: "Ormansızlaşma yolunda dakikada kesilen ağaç miktarı", link: "https://en-wikipedia-org.translate.goog/wiki/Deforestation?_x_tr_sl=en&_x_tr_tl=tr&_x_tr_hl=tr&_x_tr_pto=wa", desc: "Bu raporlar ekosistemin en önemli yapıtaşı olan ağaçların bilinçsizce yok edilmesinin istatistiki verilerini içerir." }
  ];

  return (
    <div className="min-h-screen bg-[#020617] selection:bg-emerald-500/30">
      <Navbar />
      
      {/* Arka Plan Efektleri - Mobilde daha hafif */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute top-[-5%] right-[-5%] w-[60%] h-[40%] rounded-full bg-emerald-900/10 blur-[100px] md:blur-[120px]" />
        <div className="absolute bottom-[-5%] left-[-5%] w-[60%] h-[40%] rounded-full bg-blue-900/5 blur-[100px] md:blur-[120px]" />
      </div>

      <main className="relative z-[10] max-w-4xl mx-auto p-5 md:p-6 pt-28 md:pt-40 pb-20 pointer-events-auto">
        <header className="mb-10 md:mb-16 border-l-2 border-emerald-500/30 pl-6">
          <div className="flex items-center gap-3 mb-4">
            <Database className="text-emerald-500 w-[16px] h-[16px] md:w-[20px] md:h-[20px]" />
            <span className="text-emerald-500 text-[9px] md:text-[10px] tracking-[0.3em] md:tracking-[0.5em] font-bold uppercase italic">Bilgi Merkezi</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-light text-white tracking-tighter leading-tight">
            Veri <span className="text-emerald-400 font-medium italic">Kaynakçaları</span>
          </h1>
          <p className="mt-4 text-slate-500 text-xs md:text-sm leading-relaxed max-w-xl font-light">
            Sistemimizdeki tüm veriler bilimsel temelli açık kaynaklardan ve küresel çevre organizasyonlarından anlık olarak derlenmektedir.
          </p>
        </header>

        <div className="grid gap-4 md:gap-6">
          {sources.map((s, i) => (
            <div 
              key={i} 
              className="group relative bg-white/[0.02] border border-white/5 p-5 md:p-8 rounded-2xl md:rounded-3xl backdrop-blur-md transition-all duration-500 hover:bg-white/[0.04] hover:border-emerald-500/30 active:bg-white/5"
            >
              <div className="flex justify-between items-start gap-4">
                <div className="space-y-3">
                  <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 mb-1">
                    <BookOpen className="w-[18px] h-[18px] md:w-[20px] md:h-[20px]" />
                  </div>
                  <h2 className="text-base md:text-xl font-medium text-white tracking-tight group-hover:text-emerald-400 transition-colors leading-snug">
                    {s.title}
                  </h2>
                  <p className="text-slate-400 text-[11px] md:text-sm leading-relaxed max-w-2xl font-light">
                    {s.desc}
                  </p>
                </div>
                
                {/* Dış Link Butonu - Mobilde daha büyük dokunma alanı */}
                <a 
                  href={s.link} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-3.5 md:p-3 rounded-full bg-white/5 text-slate-400 hover:bg-emerald-500 hover:text-white transition-all duration-300 flex-shrink-0 shadow-sm shadow-black"
                  aria-label="Kaynağa git"
                >
                  <ExternalLink className="w-[18px] h-[18px] md:w-[18px] md:h-[18px]" />
                </a>
              </div>

              {/* Hover Çizgisi */}
              <div className="absolute bottom-0 left-0 w-0 h-[1px] bg-gradient-to-r from-transparent via-emerald-500 to-transparent transition-all duration-700 group-hover:w-full opacity-50" />
            </div>
          ))}
        </div>

        <footer className="mt-20 md:mt-32 text-center border-t border-white/5 pt-10">
          <p className="text-[9px] md:text-[10px] text-slate-600 tracking-[0.4em] uppercase font-medium">
            Digital Awareness for Humanity &copy; 2026
          </p>
        </footer>
      </main>
    </div>
  );
}