"use client";
import { useState } from "react";
import { auth } from "@/lib/firebase";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendEmailVerification,
  signOut 
} from "firebase/auth";
import { useRouter } from "next/navigation";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);
  const router = useRouter();

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (isRegistering) {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await sendEmailVerification(userCredential.user);
        alert("Kayıt başarılı! Lütfen e-posta adresine gönderilen doğrulama linkine tıkla. Onaylamadan giriş yapamazsın.");
        await signOut(auth);
        setIsRegistering(false);
      } else {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        if (!userCredential.user.emailVerified) {
          alert("E-posta adresin henüz doğrulanmamış. Lütfen mail kutunu kontrol et.");
          await signOut(auth);
          return;
        }
        router.push("/");
      }
    } catch (error: any) {
      alert("Hata: " + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 md:p-6 font-mono text-white">
      {/* Kart Yapısı: Mobilde tam genişlik, PC'de max-w-md */}
      <div className="w-full max-w-md border border-white/10 p-6 md:p-10 rounded-[2rem] md:rounded-3xl bg-white/[0.02] backdrop-blur-sm">
        
        {/* Başlık Bölümü */}
        <header className="mb-8 md:mb-10 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-black mb-2 tracking-tighter italic text-red-600">
            DAFH ACCESS
          </h2>
          <p className="text-gray-500 text-[10px] md:text-xs uppercase tracking-[0.2em] md:tracking-widest">
            {isRegistering ? "Yeni Profil Oluştur" : "Sisteme Yetkili Girişi"}
          </p>
        </header>
        
        <form onSubmit={handleAuth} className="space-y-4 md:space-y-5">
          <div className="space-y-3">
            <input 
              type="email" 
              placeholder="E-POSTA" 
              className="w-full bg-white/5 border border-white/10 p-4 md:p-5 rounded-2xl focus:border-red-600 outline-none transition-all text-sm md:text-base placeholder:text-gray-600 focus:bg-white/[0.08]"
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input 
              type="password" 
              placeholder="ŞİFRE" 
              className="w-full bg-white/5 border border-white/10 p-4 md:p-5 rounded-2xl focus:border-red-600 outline-none transition-all text-sm md:text-base placeholder:text-gray-600 focus:bg-white/[0.08]"
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button className="w-full bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white font-bold py-4 md:py-5 rounded-2xl transition-all shadow-lg shadow-red-900/20 text-xs md:text-sm tracking-widest uppercase mt-2">
            {isRegistering ? "KAYIT OL VE DOĞRULAMA GÖNDER" : "GİRİŞ YAP"}
          </button>
        </form>

        {/* Alt Geçiş Butonu */}
        <button 
          onClick={() => setIsRegistering(!isRegistering)}
          className="w-full mt-8 text-[9px] md:text-[10px] text-gray-500 hover:text-white active:text-red-400 transition-colors uppercase tracking-[0.2em] md:tracking-widest"
        >
          {isRegistering ? "Zaten bir hesabım var → Giriş" : "Hesabın yok mu? → Kayıt Ol"}
        </button>
      </div>
    </div>
  );
}