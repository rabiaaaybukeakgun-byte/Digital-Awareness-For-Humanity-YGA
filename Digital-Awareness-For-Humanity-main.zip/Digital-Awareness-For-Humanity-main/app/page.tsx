"use client";

import { useState, useEffect } from 'react';

import { useRouter } from 'next/navigation';

import { onAuthStateChanged } from 'firebase/auth';

import { auth } from '@/lib/firebase'; 

import Navbar from '@/components/Navbar';



export default function Home() {

  const [user, setUser] = useState<any>(null);

  const [loading, setLoading] = useState(true);

  const [seconds, setSeconds] = useState<number | null>(null);

  const [isMounted, setIsMounted] = useState(false);

  const router = useRouter();



  const START_DATE = new Date('2026-02-03T23:00:00+03:00').getTime();



  useEffect(() => {

    setIsMounted(true);

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {

      if (currentUser) {

        setUser(currentUser);

        setLoading(false);

      } else {

        router.replace('/login');

      }

    });

    return () => unsubscribe();

  }, [router]);



  useEffect(() => {

    if (!isMounted || loading) return;

    const timer = setInterval(() => {

      setSeconds(Math.max(0, Math.floor((Date.now() - START_DATE) / 1000)));

    }, 1000);

    return () => clearInterval(timer);

  }, [isMounted, loading, START_DATE]);



  if (!isMounted || loading) {

    return (

      <div className="min-h-screen bg-[#020617] flex items-center justify-center text-emerald-500 font-sans tracking-[0.5em] animate-pulse">

        SİSTEME ERİŞİLİYOR...

      </div>

    );

  }



  const currentSeconds = seconds || 0;

  const hrs = currentSeconds / 3600;

  

  const stats = [

    { n: "Katledilen Köpek Balığı", v: 11415, image: "https://upload.wikimedia.org/wikipedia/commons/4/48/Blacktip_reef_shark.jpg" },

    { n: "Salınan CO2 (Ton)", v: 4566210, image: "https://tragger.com.tr/wp-content/uploads/2023/07/karbon-emisyonu-nedir-ve-nasil-azaltilabilir-1.jpg" },

    { n: "Kesilen Ağaç Sayısı", v: 1700, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPpdNBhvMny-9SP0Cw8aBLXbJLu82X1HI19w&s" },

    { n: "Hava Kirliliğine Bağlı Ölümler", v: 800, image: "https://www.niehs.nih.gov/sites/default/files/health/assets/images/air_pollution_og.jpg" },

    { n: "İklim Kaynaklı Göç Edenler", v: 880, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUr0fnBReh2NhlRsoTPsKXHcDGVagTXF66_g&s" },

    { n: "Tehdit Altındaki Türler", v: 8760, image: "https://www.ustahaberci.net/Images/galeri/_393.jpg" },

    { n: "Plastik Atık Üretimi (Ton)", v: 893 , image: "https://assets.theoceancleanup.com/scaled/1200x675/app/uploads/2023/04/Large-220604_Guatemala_Helicopter_Val_S5_pic_324-scaled.jpg" },

    { n: "AI Su Tüketimi (Litre)", v: 250000, image: "https://www.foodandwaterwatch.org/wp-content/uploads/2025/04/AI-Water-Featured-Image.png" }

  ];



  const textOutlineStyle = {
  textShadow: "0px 0px 20px rgba(16, 185, 129, 0.5), 2px 2px 10px rgba(0,0,0,1)"
};



  return (

    <main className="min-h-screen bg-[#020617] text-slate-300 font-sans selection:bg-emerald-500/30 overflow-x-hidden">

      

      {/* ÜST BAŞLIK */}

      <div className="fixed top-20 left-0 w-full flex justify-center items-center z-[60] pointer-events-none px-6">

         <div className="text-[14px] md:text-[18px] tracking-[0.4em] text-white/80 font-medium uppercase text-center bg-transparent py-2 px-4 drop-shadow-lg">

            Digital Awareness for Humanity by Gama Robotics - R.A.A.

         </div>

      </div>



      <div className="fixed inset-0 -z-10">

        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-emerald-900/10 blur-[120px] animate-pulse" />

        <div className="absolute bottom-[10%] right-[-10%] w-[50%] h-[50%] rounded-full bg-blue-900/10 blur-[120px]" />

      </div>



      <Navbar />

      

      <div className="relative flex flex-col items-center justify-center min-h-screen p-6 pt-48">

        

        {/* ANA KONSOL ALANI */}

        <div className="text-center mb-32 w-full">

          {/* SAYAÇ */}

          <h1 className="text-6xl md:text-9xl font-light tracking-tighter text-white mb-8 tabular-nums drop-shadow-2xl">

            {Math.floor(currentSeconds/86400)}<span className="text-slate-600 text-3xl mx-2 uppercase font-extralight">D</span> 

            {String(Math.floor(currentSeconds/3600)%24).padStart(2,'0')}<span className="text-slate-600 text-3xl mx-2 uppercase font-extralight">H</span>

            {String(Math.floor(currentSeconds/60)%60).padStart(2,'0')}<span className="text-slate-600 text-3xl mx-2 uppercase font-extralight">M</span>

            <span className="text-emerald-500">{String(currentSeconds%60).padStart(2,'0')}</span><span className="text-slate-600 text-3xl mx-2 uppercase font-extralight">S</span>

          </h1>

          

          {/* METİNLER */}

          <div className="max-w-4xl mx-auto flex flex-col items-center gap-5">

            <p className="text-slate-400 text-base md:text-xl font-light italic leading-relaxed opacity-90">

              "Dünyamızı bu kadar basit eğlenceler için tüketirken harcadığımız kaynakların bir sonunun olduğunu biliyor muydunuz?"

            </p>

            

            {/* SİSTEM BİLGİSİ & PROFİL GRUBU */}

            <div className="flex flex-col items-center gap-2 mt-3">

              <p className="text-slate-600 text-[10px] tracking-[0.3em] uppercase">

                Sistem Başlangıcı: 03.02.2026 | 23:00 (GMT+3)

              </p>

              {/* Profil ismini azıcık parlattım ki sistem bilgisinden ayrılsın */}

              <div className="px-4 py-1 rounded-full bg-white/5 border border-white/5 backdrop-blur-sm mt-5">

                 <p className="text-emerald-500/90 text-[10px] tracking-[0.25em] font-bold uppercase">

                   DAFH PROFIL: {user?.email?.split('@')[0]}

                 </p>

              </div>
              <div className="h-32 md:h-64 w-full"></div> 


            </div>

          </div>

        </div>



        {/* KARTLAR */}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-6xl mb-20">

          {stats.map((s) => (

            <div 

              key={s.n} 

              className="group relative h-80 rounded-[2.5rem] overflow-hidden border border-white/10 transition-all duration-500 hover:border-emerald-500/50 hover:-translate-y-2 shadow-2xl"

            >

              <div 

                className="absolute inset-0 transition-transform duration-1000 group-hover:scale-110" 

                style={{ 

                  backgroundImage: `url(${s.image})`,

                  backgroundPosition: 'center',

                  backgroundSize: 'cover',

                  backgroundRepeat: 'no-repeat'

                }}

              />

              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors duration-500" />

              <div className="relative h-full p-12 flex flex-col justify-between z-10">

                <div className="flex justify-between items-start">

                  <p style={textOutlineStyle} className="text-sm md:text-lg text-white uppercase tracking-[0.3em] font-black">

                    {s.n}

                  </p>

                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_rgba(16,185,129,1)]" />

                </div>

                <div className="flex flex-col gap-1">

                  <p style={textOutlineStyle} className="text-6xl md:text-7xl font-bold tracking-tighter text-white">

                    {Math.floor(hrs * s.v).toLocaleString('tr-TR')}

                  </p>

                  <div className="w-12 h-[3px] bg-emerald-500 rounded-full mt-2" />

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>

    </main>

  );

} 