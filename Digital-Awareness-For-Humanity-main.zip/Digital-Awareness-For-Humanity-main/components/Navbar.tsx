"use client";
import { useState, useEffect } from 'react'; // 1. ADIM: useEffect'i buraya ekledik
import { useRouter } from 'next/navigation';
import { auth } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { Menu, X, Home, Globe, Book, Heart, Mail, LogOut } from 'lucide-react';
import Link from 'next/link';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const router = useRouter();

  // 2. ADIM: BURAYA EKLEDİK
  // Menü açıkken arka planın kaymasını engeller
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    // Bileşen kapandığında (unmount) temizlik yapalım ki sayfa kilitli kalmasın
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

 
    const handleLogout = async () => {

    try {

      await signOut(auth);

      setIsOpen(false);

      window.location.href = "/login";

    } catch (error) {

      console.error("Çıkış yapılırken hata oluştu:", error);

    }

  };



  const menuItems = [

    { name: 'Ana Sayfa', icon: <Home size={22} />, href: '/' },

    { name: 'Haberler', icon: <Globe size={22} />, href: '/haberler' },

    { name: 'Kaynaklar', icon: <Book size={22} />, href: '/kaynaklar' },

    { name: 'Bağış', icon: <Heart size={22} />, href: '/bagis' },

    { name: 'İletişim', icon: <Mail size={22} />, href: '/iletisim' },

  ];



  return (

    // KRİTİK DEĞİŞİKLİK: min-h-screen kaldırıldı, h-0 eklendi.

    // Bu sayede nav içeriği olmayan boş alanlar tıklamayı arka plana geçirir.

    <nav className="fixed top-0 left-0 w-full z-[100] h-0 pointer-events-none">

     

      {/* LOGO GRUBU - Manuel ayarların burada */}

      <div

        className="absolute pointer-events-auto flex flex-col items-center"

        style={{

          top: '0px',

          left: '0px',

          transform: 'translate(0px, 0px)'

        }}

      >

        <Link href="/" className="flex flex-col items-center">

          <img 
  src="/LOGO.svg" 
  alt="Logo"
  className="object-contain w-[120px] h-[120px] md:w-[200px] md:h-[200px] -mt-5 md:-mt-10 -mb-8 md:-mb-12"
/>

          <span className="text-xl font-black text-white tracking-tighter uppercase leading-none">

            DAFH

          </span>

        </Link>

      </div>



      {/* MENÜ BUTONU - z-[120] ile panelin üstünde kalması sağlandı */}

      <div

        className="absolute pointer-events-auto z-[120]"

        style={{

          top: '40px',

          right: '40px',

        }}

      >

        <button

          onClick={() => setIsOpen(!isOpen)}

          className="text-white p-2.5 hover:scale-110 transition-all bg-white/10 rounded-full backdrop-blur-md border border-white/10"

        >

          {isOpen ? <X size={30} /> : <Menu size={30} />}

        </button>

      </div>



      {/* MOBİL MENÜ PANELİ */}

      <div className={`fixed inset-0 bg-black/90 backdrop-blur-2xl transition-all duration-500 flex flex-col justify-center items-center pointer-events-auto z-[110] ${isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>

        <ul className="space-y-8 text-left w-full max-w-xs">

          {menuItems.map((item) => (

            <li key={item.name} className={`transform transition-all duration-500 ${isOpen ? 'translate-x-0 opacity-100' : '-translate-x-8 opacity-0'}`}>

              <Link href={item.href} onClick={() => setIsOpen(false)} className="flex items-center gap-4 text-white text-2xl font-light tracking-widest hover:text-emerald-400 transition-colors uppercase">

                {item.icon} {item.name}

              </Link>

            </li>

          ))}

          <li className="pt-8 border-t border-white/10">

            <button onClick={handleLogout} className="flex items-center gap-4 text-red-600 text-2xl font-bold uppercase hover:text-red-400 transition-colors">

              <LogOut size={22} /> ÇIKIŞ YAP

            </button>

          </li>

        </ul>

      </div>

    </nav>

  );

} 